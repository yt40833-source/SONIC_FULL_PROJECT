package com.sonic.assistant;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.PermissionRequest;
import android.content.SharedPreferences;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;
    private WebViewAssetLoader assetLoader;
    private static final String PREFS = "sonic_settings";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(5,11,24));
        getWindow().setNavigationBarColor(Color.rgb(5,11,24));
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(5,11,24));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new SonicBridge(), "SonicBridge");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClient() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });
        setContentView(webView);
        if (prefs.getString("server_url", "").isEmpty()) askServerUrl(true);
        else loadApp();
    }

    private void loadApp() { webView.loadUrl("https://appassets.androidplatform.net/assets/index.html"); }

    private void askServerUrl(boolean first) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(48,24,48,8);
        TextView help = new TextView(this); help.setText("Render-এর Web Service URL এখানে বসাও। উদাহরণ: https://your-sonic.onrender.com\nএটি API Key নয়।");
        EditText input = new EditText(this); input.setSingleLine(true); input.setHint("https://your-sonic.onrender.com");
        input.setText(prefs.getString("server_url", "")); box.addView(help); box.addView(input);
        new AlertDialog.Builder(this).setTitle("SONIC Server Setup").setView(box)
            .setCancelable(!first)
            .setPositiveButton("Save", (d,w) -> {
                String url = input.getText().toString().trim().replaceAll("/+$", "");
                if (!url.startsWith("https://")) { new AlertDialog.Builder(this).setMessage("নিরাপত্তার জন্য https:// URL দিতে হবে।").setPositiveButton("OK", (a,b) -> askServerUrl(first)).show(); return; }
                prefs.edit().putString("server_url", url).apply(); loadApp();
            })
            .setNegativeButton(first ? "Exit" : "Cancel", (d,w) -> { if (first) finish(); }).show();
    }

    @Override public boolean onCreateOptionsMenu(android.view.Menu menu) {
        menu.add("SONIC Server Settings").setOnMenuItemClickListener(item -> { askServerUrl(false); return true; });
        return true;
    }
    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }

    private class SonicBridge {
        @JavascriptInterface public String getServerUrl() { return prefs.getString("server_url", ""); }
        @JavascriptInterface public void changeServerUrl() { runOnUiThread(() -> askServerUrl(false)); }
    }
}
