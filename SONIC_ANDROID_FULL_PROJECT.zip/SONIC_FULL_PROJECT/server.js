import express from "express";
import cors from "cors";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { GoogleGenAI } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT || 3000;
const MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";
const API_KEY = process.env.GEMINI_API_KEY;

app.disable("x-powered-by");
app.use(cors({ origin: ["https://appassets.androidplatform.net"] }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(API_KEY), model: MODEL });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!API_KEY) {
      return res.status(503).json({
        error: "সার্ভারে এখনো GEMINI_API_KEY সেট করা হয়নি। Render-এর Environment-এ key যোগ করো।"
      });
    }

    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "মেসেজটি খালি।" });
    if (message.length > 8000) return res.status(413).json({ error: "মেসেজটি অনেক বড়। ছোট করে পাঠাও।" });

    const history = Array.isArray(req.body?.history) ? req.body.history.slice(-20) : [];
    const contents = [];
    for (const item of history) {
      if (!item || !["user", "model"].includes(item.role) || typeof item.text !== "string") continue;
      const text = item.text.trim().slice(0, 8000);
      if (text) contents.push({ role: item.role, parts: [{ text }] });
    }

    // Avoid duplicating the latest message if it is already included in history.
    if (!contents.length || contents[contents.length - 1].role !== "user" ||
        contents[contents.length - 1].parts[0].text !== message) {
      contents.push({ role: "user", parts: [{ text: message }] });
    }

    const ai = new GoogleGenAI({ apiKey: API_KEY });
    const result = await ai.models.generateContent({
      model: MODEL,
      contents,
      config: {
        systemInstruction: "তোমার নাম SONIC। তুমি একজন সহায়ক, ভদ্র, নিরাপদ ব্যক্তিগত AI সহকারী। ব্যবহারকারীর ভাষায় উত্তর দেবে; বাংলা হলে সহজ বাংলায় বলবে। তুমি কোনো কাজ করেছ বলে দাবি করবে না যদি বাস্তবে না করে থাকো।",
        maxOutputTokens: 1200,
        temperature: 0.7
      }
    });

    const reply = (result.text || "").trim();
    if (!reply) return res.status(502).json({ error: "AI খালি উত্তর দিয়েছে। আবার চেষ্টা করো।" });
    res.json({ reply });
  } catch (error) {
    console.error("Gemini request failed:", error?.message || error);
    res.status(502).json({
      error: "AI সার্ভিসে সমস্যা হয়েছে। API key, model access ও AI Studio usage limit পরীক্ষা করো।"
    });
  }
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return res.status(404).json({ error: "API route পাওয়া যায়নি।" });
  res.sendFile(path.join(__dirname, "public", "index.html"), (err) => {
    if (err) next(err);
  });
});

app.listen(PORT, () => {
  console.log(`SONIC is running on port ${PORT}`);
});
