# SONIC Android + AI Backend

এটি SONIC-এর Android Studio project source এবং Render-এ চালানোর AI backend। APK এই পরিবেশে সরাসরি compile করা হয়নি; GitHub Actions আপনার repository-তে স্বয়ংক্রিয়ভাবে debug APK তৈরি করবে।

## ১) GitHub-এ আপলোড
ZIP extract করে ভেতরের `SONIC_FULL_PROJECT` ফোল্ডারের সব ফাইল আপনার GitHub repository-র root-এ upload করুন। `.env` বা API key upload করবেন না।

## ২) Render Backend
Render → New → Web Service → একই GitHub repository connect করুন। Build command `npm install`, Start command `npm start`। Environment Variables-এ `GEMINI_API_KEY` নামে আপনার Gemini key যোগ করুন। `GEMINI_MODEL` হলো `gemini-3.8-flash`। Deploy complete হলে `https://....onrender.com` URL কপি করুন।

## ৩) APK Build
GitHub repository → Actions → `Build SONIC Android APK` → Run workflow। সফল হলে workflow run-এর নিচে Artifacts থেকে `SONIC-Android-APK` download করুন; ZIP extract করলে `app-debug.apk` পাবেন। Android ফোনে APK install করুন। প্রথমবার SONIC খুললে Render URL চাইবে। সেখানে Render URL বসান (API key নয়)। পরে server URL বদলাতে Android app-এর server settings menu ব্যবহার করুন।

## ৪) Logo পরে বদলানো
বর্তমান temporary icon: `app/src/main/res/drawable/ic_sonic.xml`। পরে launcher icon-এর জন্য `app/src/main/res/mipmap-*` assets যোগ করে manifest-এ `android:icon` সেট করা যাবে। SONIC-এর ভেতরের artwork `app/src/main/assets/index.html`-এ আছে; সেটি বদলালে UI artwork বদলাবে।

## Features
- Bundled SONIC interface (does not require opening a website in a browser)
- Android WebView app shell
- Gemini text chat through protected Render backend
- Device speech synthesis and supported WebView speech recognition
- Local conversation history and quick commands from the supplied interface

## Important
- App-এর AI chat চালাতে internet, Render backend এবং valid Gemini API key প্রয়োজন।
- Free hosting-এ server sleep/latency/quota সীমা থাকতে পারে; Gemini usage free বা paid হবে তা Google account-এর বর্তমান quota/billing-এর ওপর নির্ভর করে।
- Android build এখানে compile/test করা হয়নি; GitHub Actions build result দেখে APK install করবেন।
- API key কখনো APK, HTML, GitHub source বা chat-এ লিখবেন না।
